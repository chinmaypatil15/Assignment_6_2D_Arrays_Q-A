from collections import defaultdict
def findOriginalArray(changed):
    count = defaultdict(int)
    for num in changed:
        count[num] += 1
    original = []
    for num in count:
        if count[num] != count[num // 2]:
            return []
        original.extend([num] * count[num])
    return origina
# Test example
changed = [1, 3, 4, 2, 6, 8]
result = findOriginalArray(changed)
print(result)
