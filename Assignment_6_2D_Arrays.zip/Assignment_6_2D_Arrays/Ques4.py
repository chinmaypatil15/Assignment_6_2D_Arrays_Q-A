def findMaxLength(nums):
    max_length = 0
    count = 0
    prefix_sums = {0: -1}
    for i in range(len(nums)):
        count += 1 if nums[i] == 1 else -1
        if count in prefix_sums:
            max_length = max(max_length, i - prefix_sums[count])
        else:
            prefix_sums[count] = i
    return max_length
# Test example
nums = [0, 1]
result = findMaxLength(nums)
print(result)
